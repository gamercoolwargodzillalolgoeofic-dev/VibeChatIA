const CACHE_NAME = "vibe-chat-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)),
      ),
    ),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Network-first for API and same-origin streaming endpoints.
  if (url.pathname.includes("/api/")) {
    return;
  }

  // Cache-first for static assets, network fallback.
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((res) => {
          if (
            res &&
            res.status === 200 &&
            res.type === "basic" &&
            (req.destination === "script" ||
              req.destination === "style" ||
              req.destination === "image" ||
              req.destination === "font" ||
              req.destination === "document")
          ) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          }
          return res;
        })
        .catch(() => cached);
    }),
  );
});
