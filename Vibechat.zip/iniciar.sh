#!/bin/bash
cd "$(dirname "$0")"
echo "========================================"
echo "  Vibe Chat - Iniciando..."
echo "========================================"
echo ""
if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] Falta Node.js. Instalalo desde https://nodejs.org"
  exit 1
fi
if [ ! -f .env ]; then
  echo "[ERROR] Falta el archivo .env."
  echo ""
  echo "  1. Copia el archivo '.env.ejemplo' a '.env'"
  echo "     cp .env.ejemplo .env"
  echo "  2. Abrilo y pon tu clave de OpenAI"
  echo "     Tu clave: https://platform.openai.com/api-keys"
  exit 1
fi
node iniciar.mjs
