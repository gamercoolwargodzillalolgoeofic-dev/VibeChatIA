@echo off
title Vibe Chat
echo ========================================
echo   Vibe Chat - Iniciando...
echo ========================================
echo.
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Falta Node.js. Instalalo desde https://nodejs.org
  pause
  exit /b 1
)
if not exist .env (
  echo No se encontro el archivo .env
  echo Ejecuta primero "configurar.bat" para ingresar tu clave de OpenAI.
  echo.
  pause
  exit /b 1
)
echo Iniciando Vibe Chat...
node iniciar.mjs
pause
