@echo off
title Vibe Chat - Configuracion
echo ========================================
echo   Vibe Chat - Configuracion inicial
echo ========================================
echo.
echo Para usar Vibe Chat necesitas una clave de OpenAI.
echo Conseguila gratis en: https://platform.openai.com/api-keys
echo.
set /p CLAVE="Pega tu clave de OpenAI aqui y presiona Enter: "
echo.
if "%CLAVE%"=="" (
  echo [ERROR] No ingresaste ninguna clave.
  pause
  exit /b 1
)
echo AI_INTEGRATIONS_OPENAI_API_KEY=%CLAVE%> .env
echo PORT=5173>> .env
echo.
echo Clave guardada correctamente!
echo Ahora abre iniciar.bat para encender Vibe Chat.
echo.
pause
