# Vibe Chat — Version portable

Sin npm install, sin PostgreSQL. Solo necesitas Node.js y una clave de OpenAI.
Tus chats se guardan en un archivo local `vibe-chat.db` en esta carpeta.

## 1. Instalar Node.js (una sola vez)
Descarga la version LTS desde https://nodejs.org e instalala.

## 2. Conseguir clave de OpenAI (una sola vez)
Entra a https://platform.openai.com/api-keys, crea una cuenta y genera una clave (empieza con sk-...).

## 3. Configurar (una sola vez)
1. En esta carpeta hay un archivo `.env.ejemplo`
2. Copialo y renombralo a `.env` (con el punto adelante)
3. Abrilo con el bloc de notas y reemplaza la clave de ejemplo con la tuya
4. Guarda y cierra

El .env debe quedar asi:
```
AI_INTEGRATIONS_OPENAI_API_KEY=sk-proj-xxxxxxxxxx
PORT=5173
```

## 4. Encender la app
- Windows: doble clic en `iniciar.bat`
- Mac/Linux: doble clic en `iniciar.sh` o ejecuta `./iniciar.sh` en la terminal

Despues de unos segundos abre en el navegador: http://localhost:5173

Para cerrar: Ctrl+C en la ventana negra.

## Problemas comunes
- La IA no responde: verifica que tu clave de OpenAI sea valida y tenga saldo
- Puerto ocupado: cambia PORT=5173 por otro numero en .env (ej: PORT=3000)
- Error de version: actualiza Node.js desde https://nodejs.org (necesitas v22+)

Creado por warIACreator.
