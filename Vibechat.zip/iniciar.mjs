#!/usr/bin/env node
// Vibe Chat — Servidor portable
// Solo necesita Node.js 22+ y una clave de OpenAI.
// Sin npm install, sin PostgreSQL, sin dependencias externas.

import { DatabaseSync } from "node:sqlite";
import http from "node:http";
import https from "node:https";
import { readFileSync, statSync, createReadStream, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const ENV_FILE = path.join(__dirname, ".env");
if (!existsSync(ENV_FILE)) {
  console.error("\n[ERROR] Falta el archivo .env en esta carpeta.");
  console.error('Copia ".env.ejemplo" a ".env", abrilo y completa tu clave de OpenAI.\n');
  process.exit(1);
}
for (const line of readFileSync(ENV_FILE, "utf8").split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
  if (!m) continue;
  let val = m[2].trim();
  if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
  if (!process.env[m[1]]) process.env[m[1]] = val;
}

const OPENAI_KEY = process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY;
const OPENAI_BASE = (process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
const PORT = parseInt(process.env.PORT || "5173", 10);

if (!OPENAI_KEY) {
  console.error("[ERROR] Falta AI_INTEGRATIONS_OPENAI_API_KEY en .env");
  process.exit(1);
}

const MODEL_MAP = {
  "gpt-5.4": "gpt-4o", "gpt-5": "gpt-4o", "gpt-5-mini": "gpt-4o-mini",
  "gpt-5-nano": "gpt-4o-mini", "o4-mini": "gpt-4o-mini",
};
function resolveModel(m) { return MODEL_MAP[m] || m || "gpt-4o"; }

const DB_FILE = path.join(__dirname, "vibe-chat.db");
const db = new DatabaseSync(DB_FILE);
db.exec(`
  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
    model TEXT NOT NULL DEFAULT 'gpt-4o', created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

function openaiRequest(messages, model, maxTokens) {
  return new Promise((resolve, reject) => {
    const url = new URL(OPENAI_BASE + "/chat/completions");
    const payload = JSON.stringify({ model, max_completion_tokens: maxTokens, messages });
    const lib = url.protocol === "http:" ? http : https;
    const req = lib.request({
      hostname: url.hostname, port: url.port ? parseInt(url.port) : (url.protocol === "http:" ? 80 : 443),
      path: url.pathname + url.search, method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${OPENAI_KEY}`, "Content-Length": Buffer.byteLength(payload) },
    }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => { try { resolve(JSON.parse(data)); } catch { reject(new Error("JSON invalido: " + data)); } });
    });
    req.on("error", reject); req.write(payload); req.end();
  });
}

function openaiStream(messages, model, onChunk, onDone, onError) {
  const url = new URL(OPENAI_BASE + "/chat/completions");
  const payload = JSON.stringify({ model, max_tokens: 8192, messages, stream: true });
  const lib = url.protocol === "http:" ? http : https;
  let done = false;
  const req = lib.request({
    hostname: url.hostname, port: url.port ? parseInt(url.port) : (url.protocol === "http:" ? 80 : 443),
    path: url.pathname + url.search, method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${OPENAI_KEY}`, "Content-Length": Buffer.byteLength(payload) },
  }, (res) => {
    let buf = "";
    if (res.statusCode !== 200) {
      let errData = "";
      res.on("data", (c) => (errData += c));
      res.on("end", () => {
        console.error(`\n[ERROR OpenAI] HTTP ${res.statusCode}: ${errData}`);
        if (!done) { done = true; onError(new Error(`HTTP ${res.statusCode}: ${errData}`)); }
      });
      return;
    }
    res.on("data", (chunk) => {
      buf += chunk.toString();
      const lines = buf.split("\n"); buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const raw = line.slice(6).trim();
        if (raw === "[DONE]") { if (!done) { done = true; onDone(); } return; }
        try { const p = JSON.parse(raw); const c = p.choices?.[0]?.delta?.content; if (c) onChunk(c); } catch {}
      }
    });
    res.on("end", () => { if (!done) { done = true; onDone(); } });
  });
  req.setTimeout(60000, () => { req.destroy(new Error("Timeout: OpenAI tardó más de 60 segundos")); });
  req.on("error", (err) => { console.error("\n[ERROR red]", err.message); if (!done) { done = true; onError(err); } });
  req.write(payload); req.end();
}

const WEB_DIR = path.join(__dirname, "web");
const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
  ".webp": "image/webp", ".ico": "image/x-icon",
  ".woff": "font/woff", ".woff2": "font/woff2", ".webmanifest": "application/manifest+json",
};
function serveStatic(req, res) {
  let urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
  if (urlPath === "/" || !urlPath) urlPath = "/index.html";
  let fp = path.join(WEB_DIR, urlPath);
  if (!fp.startsWith(WEB_DIR)) { res.writeHead(403); res.end(); return; }
  let stat;
  try { stat = statSync(fp); if (stat.isDirectory()) { fp = path.join(fp, "index.html"); stat = statSync(fp); } }
  catch { fp = path.join(WEB_DIR, "index.html"); try { stat = statSync(fp); } catch { res.writeHead(404); res.end("Not found"); return; } }
  const ext = path.extname(fp).toLowerCase();
  res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream", "Content-Length": stat.size, "Cache-Control": "no-cache" });
  createReadStream(fp).pipe(res);
}

function readBody(req) {
  return new Promise((r) => { let s = ""; req.on("data", (c) => (s += c)); req.on("end", () => { try { r(JSON.parse(s)); } catch { r({}); } }); });
}
function json(res, status, data) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const b = JSON.stringify(data);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(b) });
  res.end(b);
}
function serConv(r) { return { id: r.id, title: r.title, model: r.model, createdAt: r.created_at }; }
function serMsg(r) { return { id: r.id, conversationId: r.conversation_id, role: r.role, content: r.content, createdAt: r.created_at }; }

async function handleApi(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }
  const url = new URL(req.url, "http://localhost");
  const parts = url.pathname.replace(/^\/api\/openai\//, "").split("/").filter(Boolean);
  const method = req.method;

  if (parts[0] === "conversations" && !parts[1] && method === "GET") {
    return json(res, 200, db.prepare("SELECT * FROM conversations ORDER BY created_at DESC").all().map(serConv));
  }
  if (parts[0] === "conversations" && !parts[1] && method === "POST") {
    const body = await readBody(req);
    const model = resolveModel(body.model);
    const row = db.prepare("INSERT INTO conversations (title, model) VALUES (?, ?) RETURNING *").get((body.title || "Nueva conversacion").slice(0, 200), model);
    return json(res, 201, serConv(row));
  }
  if (parts[0] === "conversations" && parts[1] && !parts[2] && method === "GET") {
    const conv = db.prepare("SELECT * FROM conversations WHERE id = ?").get(parseInt(parts[1]));
    if (!conv) return json(res, 404, { error: "Not found" });
    const msgs = db.prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC").all(conv.id);
    return json(res, 200, { ...serConv(conv), messages: msgs.map(serMsg) });
  }
  if (parts[0] === "conversations" && parts[1] && !parts[2] && method === "DELETE") {
    const id = parseInt(parts[1]);
    db.prepare("DELETE FROM messages WHERE conversation_id = ?").run(id);
    const r = db.prepare("DELETE FROM conversations WHERE id = ?").run(id);
    if (r.changes === 0) return json(res, 404, { error: "Not found" });
    res.writeHead(204); res.end(); return;
  }
  if (parts[0] === "conversations" && parts[1] && parts[2] === "messages" && method === "GET") {
    return json(res, 200, db.prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC").all(parseInt(parts[1])).map(serMsg));
  }
  if (parts[0] === "conversations" && parts[1] && parts[2] === "messages" && method === "POST") {
    const id = parseInt(parts[1]);
    const body = await readBody(req);
    const userContent = (body.content || "").trim();
    if (!userContent) return json(res, 400, { error: "Mensaje vacio" });
    const conv = db.prepare("SELECT * FROM conversations WHERE id = ?").get(id);
    if (!conv) return json(res, 404, { error: "Not found" });
    const model = resolveModel(body.model || conv.model);
    db.prepare("INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?, 'user', ?, datetime('now'))").run(id, userContent);
    if (!conv.title || conv.title === "Nueva conversacion") {
      const t = userContent.slice(0, 60).replace(/\s+/g, " ").trim();
      if (t) db.prepare("UPDATE conversations SET title = ? WHERE id = ?").run(t, id);
    }
    if (model !== conv.model) db.prepare("UPDATE conversations SET model = ? WHERE id = ?").run(model, id);
    const history = db.prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC").all(id);
    const memRows = db.prepare("SELECT * FROM memories ORDER BY created_at DESC LIMIT 40").all();
    const memBlock = memRows.length > 0 ? "\n\nCosas que recuerdas del usuario:\n" + memRows.map((m) => "- " + m.content).join("\n") : "";
    const systemPrompt = "Eres Vibe, un asistente de IA amistoso, claro y util. Fuiste creado por warIACreator (un grupo). Respondes en el idioma del usuario (por defecto espanol). Cuando ayudes con codigo, usa bloques markdown. Se directo, calido y honesto." + memBlock;
    const chatMessages = [{ role: "system", content: systemPrompt }, ...history.map((m) => ({ role: m.role, content: m.content }))];
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no", "Access-Control-Allow-Origin": "*" });
    let fullResp = "";
    openaiStream(chatMessages, model,
      (chunk) => { fullResp += chunk; res.write("data: " + JSON.stringify({ content: chunk }) + "\n\n"); },
      () => {
        if (fullResp.trim()) db.prepare("INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?, 'assistant', ?, datetime('now'))").run(id, fullResp);
        res.write("data: " + JSON.stringify({ done: true }) + "\n\n"); res.end();
        if (fullResp.trim()) extractMemories(userContent, fullResp).catch(() => {});
      },
      (err) => {
        console.error("\n[ERROR] Fallo al llamar a OpenAI:", err.message);
        const msg = err.message.includes("401")
          ? "❌ Clave de OpenAI inválida. Revisá el archivo .env y asegurate que la clave empiece con sk- y sea correcta."
          : err.message.includes("429")
          ? "❌ Límite de uso alcanzado en tu cuenta de OpenAI. Esperá unos minutos o revisá tu saldo en platform.openai.com."
          : err.message.includes("insufficient")
          ? "❌ Tu cuenta de OpenAI no tiene créditos. Recargá en platform.openai.com/settings/billing."
          : `❌ Error al conectar con OpenAI: ${err.message}`;
        try { res.write("data: " + JSON.stringify({ content: msg }) + "\n\n"); res.write("data: " + JSON.stringify({ done: true }) + "\n\n"); res.end(); } catch {}
      }
    );
    return;
  }
  json(res, 404, { error: "Ruta no encontrada" });
}

async function extractMemories(userMsg, assistantMsg) {
  try {
    const prompt = `Extrae hechos duraderos sobre el USUARIO. Devuelve SOLO un JSON array. Incluye: nombre, profesion, ubicacion, preferencias, proyectos, tecnologias. NO incluyas preguntas tecnicas ni codigo. Tercera persona. Max 5. Si nada: []. Usuario: """${userMsg.slice(0, 600)}""" Asistente: """${assistantMsg.slice(0, 600)}"""`;
    const result = await openaiRequest([{ role: "user", content: prompt }], "gpt-4o-mini", 300);
    const raw = (result.choices?.[0]?.message?.content || "").trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
    let facts; try { facts = JSON.parse(raw); } catch { const m = raw.match(/\[[\s\S]*\]/); if (!m) return; facts = JSON.parse(m[0]); }
    if (!Array.isArray(facts)) return;
    const newFacts = facts.filter((f) => typeof f === "string").map((f) => f.trim()).filter((f) => f.length >= 4 && f.length <= 240);
    if (!newFacts.length) return;
    const exLow = db.prepare("SELECT content FROM memories").all().map((m) => m.content.toLowerCase());
    const toInsert = newFacts.filter((f) => { const lo = f.toLowerCase(); return !exLow.some((e) => e === lo || e.includes(lo) || lo.includes(e)); });
    if (!toInsert.length) return;
    const stmt = db.prepare("INSERT INTO memories (content, created_at) VALUES (?, datetime('now'))");
    for (const c of toInsert) stmt.run(c);
    const count = db.prepare("SELECT COUNT(*) as n FROM memories").get().n;
    if (count > 100) { const oldest = db.prepare("SELECT id FROM memories ORDER BY created_at ASC LIMIT ?").all(count - 100); const del = db.prepare("DELETE FROM memories WHERE id = ?"); for (const r of oldest) del.run(r.id); }
  } catch {}
}

const server = http.createServer(async (req, res) => {
  try { if ((req.url || "/").startsWith("/api/")) await handleApi(req, res); else serveStatic(req, res); }
  catch (err) { console.error("Error:", err.message); if (!res.headersSent) { res.writeHead(500); res.end("Error interno"); } }
});

server.listen(PORT, () => {
  console.log("\n==========================================");
  console.log(`  Vibe Chat corriendo en http://localhost:${PORT}`);
  console.log("==========================================");
  console.log("\n  Abri esa direccion en tu navegador.");
  console.log("  Para cerrar: Ctrl+C\n");
});
process.on("SIGINT", () => { try { db.close(); } catch {} process.exit(0); });
process.on("SIGTERM", () => { try { db.close(); } catch {} process.exit(0); });
